package com.ecom.Service.impl;

import com.ecom.Model.Cart;
import com.ecom.Model.Product;
import com.ecom.Model.User;
import com.ecom.Repository.CartRepository;
import com.ecom.Repository.ProductRepository;
import com.ecom.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public void addToCart(User user, Integer productId, int quantity) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null || product.getStockQuantity() < quantity) {
            throw new RuntimeException("Product not available in sufficient quantity");
        }

        Cart existing = cartRepository.findByUserAndProduct_ProductId(user, productId);
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + quantity);
            cartRepository.save(existing);
        } else {
            Cart newCart = new Cart();
            newCart.setUser(user);
            newCart.setProduct(product);
            newCart.setQuantity(quantity);
            cartRepository.save(newCart);
        }
    }

    @Override
    public List<Cart> getUserCart(User user) {
        return cartRepository.findByUser(user);
    }

    @Override
    public void removeFromCart(Long cartId) {
        cartRepository.deleteById(cartId);
    }

    @Override
    public void clearCart(User user) {
        List<Cart> userCarts = cartRepository.findByUser(user);
        cartRepository.deleteAll(userCarts);
    }
}
