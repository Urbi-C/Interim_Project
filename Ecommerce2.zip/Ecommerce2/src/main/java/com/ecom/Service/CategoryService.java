package com.ecom.Service;

import com.ecom.Model.Category;
import java.util.List;

public interface CategoryService {
    List<Category> getAllCategories();
    Category getCategoryById(Integer id);
    Category saveCategory(Category category);
    void deleteCategory(int id);
}
