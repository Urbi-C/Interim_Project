package com.ecom.Service;

import com.ecom.Model.Cart;
import com.ecom.Model.User;
import java.util.List;


public interface CartService {
    void addToCart(User user, Integer productId, int quantity);
    List<Cart> getUserCart(User user);
    void removeFromCart(Long cartId);
    void clearCart(User user);
}
