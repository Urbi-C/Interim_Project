package com.ecom.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecom.Model.User;
import com.ecom.Service.ProductService;
import com.ecom.Service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private ProductService productService;


    // 🏠 Home Page
    @GetMapping({"/", "/home"})
    public String showHomePage(HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");

        if (loggedInUser != null) {
            // Redirect based on role
            if (loggedInUser.getRole() == User.Role.ADMIN) {
                return "redirect:/admin/dashboard";
            } else {
                return "redirect:/user/dashboard";
            }
        }

        return "home"; // visible to guests
    }

    // 🔐 Login Page
    @GetMapping("/users/login")
    public String showLoginPage() {
        return "login";
    }

    // 🧾 Register Page
    @GetMapping("/users/register")
    public String showRegisterPage() {
        return "register";
    }

    // 🧑‍💻 Handle Registration
    @PostMapping("/users/register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
        try {
            // Assign CUSTOMER role automatically
            //user.setRole(User.Role.CUSTOMER);
            userService.registerUser(user);

            model.addAttribute("success", "Registration successful! Please login.");
            return "login";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "register";
        }
    }

    // 🔑 Handle Login (Role-Based Redirection)
    @PostMapping("/users/login")
    public String loginUser(@RequestParam String username,
                            @RequestParam String password,
                            HttpSession session,
                            Model model) {
        User loggedIn = userService.loginUser(username, password);

        if (loggedIn != null) {
            session.setAttribute("loggedInUser", loggedIn);

            if (loggedIn.getRole() == User.Role.ADMIN) {
                return "redirect:/admin/dashboard";
            } else if (loggedIn.getRole() == User.Role.CUSTOMER) {
                return "redirect:/user/dashboard";
            }
        }

        model.addAttribute("error", "Invalid username or password.");
        return "login";
    }

    // 🚪 Logout
    @GetMapping("/users/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/home";
    }

    // 👤 User Dashboard
    @GetMapping("/user/dashboard")
    public String userDashboard(HttpSession session) {
        User loggedIn = (User) session.getAttribute("loggedInUser");

        // Only allow CUSTOMER role
        if (loggedIn == null || loggedIn.getRole() != User.Role.CUSTOMER) {
            return "redirect:/users/login";
        }
        return "user-dashboard";
    }

    // 🧑‍💼 Admin Dashboard
    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session) {
        User loggedIn = (User) session.getAttribute("loggedInUser");

        // Only allow ADMIN role
        if (loggedIn == null || loggedIn.getRole() != User.Role.ADMIN) {
            return "redirect:/users/login";
        }
        return "admin-dashboard";
    }
 // View profile
    @GetMapping("/user/profile")
    public String viewProfile(HttpSession session, Model model) {
        User loggedIn = (User) session.getAttribute("loggedInUser");
        if (loggedIn == null || loggedIn.getRole() != User.Role.CUSTOMER) {
            return "redirect:/users/login";
        }
        model.addAttribute("user", loggedIn);
        return "user/profile"; // JSP page for profile
    }

    // Update profile
    @PostMapping("/user/profile")
    public String updateProfile(@ModelAttribute("user") User updatedUser,
                                HttpSession session,
                                Model model) {
        User loggedIn = (User) session.getAttribute("loggedInUser");
        if (loggedIn == null || loggedIn.getRole() != User.Role.CUSTOMER) {
            return "redirect:/users/login";
        }

        User savedUser = userService.updateUserProfile(loggedIn.getId(), updatedUser);
        if (savedUser != null) {
            session.setAttribute("loggedInUser", savedUser); // Update session
            model.addAttribute("successMessage", "Profile updated successfully.");
        } else {
            model.addAttribute("errorMessage", "Failed to update profile.");
        }
        model.addAttribute("user", savedUser);
        return "user/profile";
    }
    
    @GetMapping("/user/products")
    public String viewProducts(Model model, HttpSession session) {
        User loggedIn = (User) session.getAttribute("loggedInUser");

        // Ensure only logged-in customers can access
        if (loggedIn == null || loggedIn.getRole() != User.Role.CUSTOMER) {
            return "redirect:/users/login";
        }

        model.addAttribute("products", productService.getAllProducts());
        return "user/products"; // JSP: /WEB-INF/views/user/products.jsp
    }

}
