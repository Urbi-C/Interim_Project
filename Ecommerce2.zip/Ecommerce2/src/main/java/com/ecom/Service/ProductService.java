package com.ecom.Service;

import java.util.List;

import com.ecom.Model.Product;

public interface ProductService {
	    Product saveProduct(Product p);
	    List<Product> getAllProducts();
	    Product getProductById(Integer id);
	    void deleteProduct(Integer id);
	    List<Product> findByCategory(Integer categoryId);
}
