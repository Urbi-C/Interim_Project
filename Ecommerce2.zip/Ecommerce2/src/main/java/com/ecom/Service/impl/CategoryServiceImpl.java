package com.ecom.Service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.Model.Category;
import com.ecom.Repository.CategoryRepository;
import com.ecom.Repository.ProductRepository;
import com.ecom.Service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;
    
    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }

    @Override
    public Category getCategoryById(Integer id) {
        return categoryRepository.findById(id).orElse(null);
    }

    @Override
    public Category saveCategory(Category category) {
        return categoryRepository.save(category);
    }

    @Override
    public void deleteCategory(int id) {
        if (productRepository.existsByCategoryCategoryId(id)) {
            throw new RuntimeException("Cannot delete category. Products are associated with it.");
        }
        categoryRepository.deleteById(id);
    }
}
