package com.ecom.Repository;

import com.ecom.Model.Cart;
import com.ecom.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CartRepository extends JpaRepository<Cart, Long> {
    List<Cart> findByUser(User user);
    Cart findByUserAndProduct_ProductId(User user, Integer productId);
}
