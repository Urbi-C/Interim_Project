package com.ecom.Controller;

import com.ecom.Model.Category;
import com.ecom.Service.CategoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/categories") // All category URLs start with /admin/categories
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    // 📜 View all categories
    @GetMapping
    public String viewCategories(Model model) {
        List<Category> categories = categoryService.getAllCategories();
        model.addAttribute("categories", categories);
        model.addAttribute("category", new Category());
        return "admin/admin-categories";
    }

    // ➕ Add new category
    @PostMapping("/add")
    public String addCategory(@ModelAttribute Category category) {
        categoryService.saveCategory(category);
        return "redirect:/admin/categories";
    }

    // ❌ Delete category
    @GetMapping("/delete/{id}")
    public String deleteCategory(@PathVariable("id") int id, Model model) {
        try {
            categoryService.deleteCategory(id);
            return "redirect:/admin/categories";
        } catch (Exception e) {
            // Fetch all categories again to show on the page
            List<Category> categories = categoryService.getAllCategories();
            model.addAttribute("categories", categories);
            model.addAttribute("category", new Category());
            model.addAttribute("errorMessage", e.getMessage()); // Add error message
            return "admin/admin-categories"; // Stay on the same page
        }
    }
}
