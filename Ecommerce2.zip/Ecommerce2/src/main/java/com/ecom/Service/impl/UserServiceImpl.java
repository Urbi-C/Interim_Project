package com.ecom.Service.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ecom.Model.User;
import com.ecom.Repository.UserRepository;
import com.ecom.Service.UserService;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder ;

    @Override
    public User registerUser(User user) {
        if (userRepository.findByEmail(user.getEmail()) != null) {
            throw new RuntimeException("Email already registered");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
       // if (user.getRole() == null) user.setRole(User.Role.CUSTOMER);
           user.setRole(User.Role.CUSTOMER);
        return userRepository.save(user);
    }

    @Override
    public User loginUser(String username, String password) {
        User existingUser = userRepository.findByUsername(username);
        if (existingUser != null && passwordEncoder.matches(password, existingUser.getPassword())) {
            return existingUser;
        }
        return null;
    }

    @Override
    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }

    @Override
    public User updateUserProfile(Long userId, User updatedUser) {
        User existingUser = getUserById(userId);
        if (existingUser != null) {
            existingUser.setEmail(updatedUser.getEmail());
            existingUser.setUsername(updatedUser.getUsername());
            return userRepository.save(existingUser);
        }
        return null;
    }
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // ✅ New method: Delete user by ID
    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
}
