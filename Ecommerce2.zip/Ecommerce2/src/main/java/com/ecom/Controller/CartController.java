package com.ecom.Controller;

import com.ecom.Model.Cart;
import com.ecom.Model.Product;
import com.ecom.Model.User;
import com.ecom.Service.CartService;
import com.ecom.Service.ProductService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;
     
    @Autowired
    private ProductService productService;
    // 🛒 Add product to cart
 // 🛒 Add product to cart
    @PostMapping("/add/{productId}")
    public String addToCart(@PathVariable("productId") int productId,
                            @RequestParam("quantity") int quantity,
                            HttpSession session,
                            Model model) {
        User loggedIn = (User) session.getAttribute("loggedInUser");
        if (loggedIn == null) {
            return "redirect:/users/login";
        }

        // ✅ Use productId as per service interface
        cartService.addToCart(loggedIn, productId, quantity);

        // ✅ Reload the product list
        model.addAttribute("products", productService.getAllProducts());
        // ✅ Show popup message
        model.addAttribute("successMessage", "Product added to cart successfully!");

        return "user/products"; // Stay on same page
    }

    // 📋 View cart
    @GetMapping
    public String viewCart(HttpSession session, Model model) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/users/login";

        List<Cart> cartItems = cartService.getUserCart(user);
        model.addAttribute("cartItems", cartItems);
        return "user/cart";
    }

    // ❌ Remove from cart
    @GetMapping("/remove/{cartId}")
    public String removeItem(@PathVariable Long cartId, HttpSession session) {
        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) return "redirect:/users/login";

        cartService.removeFromCart(cartId);
        return "redirect:/cart";
    }
}
