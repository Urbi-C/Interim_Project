package com.ecom.Service;

import java.util.List;

import com.ecom.Model.User;

public interface UserService {
    User registerUser(User user);
    User loginUser(String username, String password);
    User getUserById(Long userId);
    User updateUserProfile(Long userId, User updatedUser);
    
    List<User> getAllUsers();
    void deleteUser(Long userId);
}
