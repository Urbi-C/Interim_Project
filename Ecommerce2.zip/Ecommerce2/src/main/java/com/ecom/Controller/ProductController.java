package com.ecom.Controller;

import com.ecom.Model.Product;
import com.ecom.Model.Category;
import com.ecom.Service.ProductService;
import com.ecom.Service.CategoryService;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @Autowired
    private CategoryService categoryService;

    // 👀 User: View all products
    @GetMapping("/view")
    public String viewAllProducts(Model model, HttpSession session) {
        List<Product> products = productService.getAllProducts();
        model.addAttribute("products", products);
        return "products"; // /WEB-INF/views/products.jsp
    }

    // 🧑‍💼 Admin: Manage Products
    @GetMapping()
    public String adminProductPage(Model model, HttpSession session) {
        List<Product> products = productService.getAllProducts();
        List<Category> categories = categoryService.getAllCategories();

        model.addAttribute("products", products);
        model.addAttribute("categories", categories);
        model.addAttribute("product", new Product());
        return "admin/admin-products";
    }

    // ➕ Admin: Add Product
    @PostMapping("/add")
    public String addProduct(@ModelAttribute Product product,
                             @RequestParam("categoryId") Integer categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        product.setCategory(category);
        productService.saveProduct(product);
        return "redirect:/admin/products";
    }

    // ❌ Admin: Delete Product
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable("id") Integer id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products";
    }

    // ✏️ Admin: Edit Product
    @GetMapping("/edit/{id}")
    public String editProduct(@PathVariable("id") Integer id, Model model) {
        Product product = productService.getProductById(id);
        List<Category> categories = categoryService.getAllCategories();

        model.addAttribute("product", product);
        model.addAttribute("categories", categories);
        return "admin/edit-product";
    }

    @PostMapping("/update")
    public String updateProduct(@ModelAttribute Product product,
                                @RequestParam("categoryId") Integer categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        product.setCategory(category);
        productService.saveProduct(product);
        return "redirect:/admin/products";
    }
}
