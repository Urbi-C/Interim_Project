package com.ecom.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Product 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
  private int productId;
	@Column(nullable = false, length = 100)
  private String name;
	@Column(columnDefinition = "TEXT")
  private String discription;
	@Column(nullable = false)
  private Double price;
	@ManyToOne(fetch = FetchType.LAZY)
  private Category category;
	@Column(nullable = false)
  private int stockQuantity;
	
	
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Product(int productId, String name, String discription, Double price, Category category,
			int stockQuantity) {
		super();
		this.productId = productId;
		this.name = name;
		this.discription = discription;
		this.price = price;
		this.category = category;
		this.stockQuantity = stockQuantity;
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
