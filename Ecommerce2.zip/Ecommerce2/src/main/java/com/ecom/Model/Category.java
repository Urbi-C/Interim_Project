package com.ecom.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Category 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
   private int categoryId;
	@Column(nullable = false, unique = true)
   private String name;
   
   
   public Category() {
	super();
	// TODO Auto-generated constructor stub
}
   public Category(int categoryId, String name) {
	super();
	this.categoryId = categoryId;
	this.name = name;
}
   public int getCategoryId() {
	return categoryId;
   }
   public void setCategoryId(int categoryId) {
	this.categoryId = categoryId;
   }
   public String getName() {
	return name;
   }
   public void setName(String name) {
	this.name = name;
   }
  
   
   
}
